function love.conf(t)
         t.identity = "Game.love"
         t.title = "KEK"
		 t.version = "0.10.1"
		 t.window.width = 0
		 t.window.height = 0
		 t.console = true
		 t.window.borderless = true
		 --t.window.icon = 'assets/logo.png'
end
	 